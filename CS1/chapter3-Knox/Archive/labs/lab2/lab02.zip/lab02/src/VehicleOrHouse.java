public class VehicleOrHouse
{
    public static void main(String[] args)
    {
        // TODO: Draw a vechicle.
        // It can be a car, truck, bus, bike, spaceship, Tardis, etc.
        // Be creative!
        //
        // Or it can be a house, with at least one door, 
        // at least one window, and a roof.
        System.out.println("\n\nDraw a vehicle\n\n");

        // your code here:
        
    }
    
}
