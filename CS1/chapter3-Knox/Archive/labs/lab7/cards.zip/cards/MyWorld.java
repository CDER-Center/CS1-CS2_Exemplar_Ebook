import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    // array to hold the cards
    Card[] cards;
    int cardNum;
    int offset;
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        
        // array of 52 cards
        cards = new Card[52];
        int index = 0;
        String[] suits = {"H", "D", "C", "S"};
        for (String suit : suits)
        {
            for (int rank = 2; rank <= 14; rank++)
            {
                cards[index] = new Card(rank, suit);
                index++;
            }
        }
    }
    
    public void act()
    {
        if (Greenfoot.mouseClicked(this))
        {
            MouseInfo info = Greenfoot.getMouseInfo();
            if (info.getButton() == 1)
            {
                //System.out.println("clicked");
                
                // mod by 52 to get into 0 to 51 range
                Card card = cards[cardNum % 52];
                cardNum++;
                // remove all of the objects on the screen
                
                // put the card on the screen
                addObject(card, 50 + offset * 40, 200);
                offset++;
            }
            else if (info.getButton() == 2 || info.getButton() == 3)
            {
                // remove all of the cards
                List<Card> cardsOnScreen = getObjects(Card.class);
                removeObjects(cardsOnScreen);
                offset = 0;
            }
        }
    }
}
