import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Card here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Card extends Actor
{
    GreenfootImage image;
    int rank;
    String suit;
    
    public static String toRankString(int rank)
    {
        // convert 11, 12, 13, 14, 15 to J Q K A
        if (rank == 11) return "J";
        if (rank == 12) return "Q";
        if (rank == 13) return "K";
        if (rank == 14) return "A";
        
        // otherwise convert the number to a String
        return rank + "";
    }
    
    public String toString()
    {
        return toRankString(this.rank) + this.suit;
    }
    
    /**
     * Create a card with a String like
     * 2H or TC
     */
    public Card(int rank, String suit)
    {
        this.rank = rank;
        this.suit = suit;
        String filename = toRankString(rank) + suit + ".png";
        this.image = new GreenfootImage("images/cards/" + filename);
        setImage(image);
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
