import java.util.Scanner;

public class PrintX 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter a positive number ");
        int num = sc.nextInt();
        for (int i=0; i<num; i++)
        {
            System.out.print("X");
        }
        System.out.println();

        sc.close();
    }
}
