public class PrintRect {
    public static void main(String[] args) {
        int rows = 4;
        int cols = 5;
        
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (c == 0 || c == cols - 1 || r == 0 || r == rows - 1)
                {
                    System.out.print("X");
                }
                else 
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
    
}
