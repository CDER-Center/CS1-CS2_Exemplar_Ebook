public class TripleLoop 
{

    public static void main(String[] args)
    {
        int sum = 0;
        for (int j = 0; j < 10; j++) {
            for (int i = 0; i < 75; i++) {
                for (int k = 0; k < 20; k++) {
                    sum++;
                }
            }
        }
        System.out.println(sum);

    }
    
}
