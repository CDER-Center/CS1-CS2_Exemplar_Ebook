public class PrintTriangle
{

    public static void main(String[] args)
    {
        int rows = 7;

        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < r+1; c++)
            {
                System.out.print("X");
            }
            System.out.println();
        }
    }
    
}
