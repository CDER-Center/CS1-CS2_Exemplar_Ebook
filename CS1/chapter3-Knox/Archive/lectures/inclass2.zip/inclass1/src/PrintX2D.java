import java.util.Scanner;

public class PrintX2D {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter num rows");
        int rows = sc.nextInt();
        System.out.println("Enter num cols");
        int cols = sc.nextInt();
        
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                System.out.print("X");
            }
            System.out.println();
        }

        sc.close();
    }
}
