public class Movie 
{
    private String title;
    private Date releaseDate;
    private Actor[] actors;
    private int numActors;

    public Movie(String t, Date d)
    {
        title = t;
        releaseDate = d;
        actors = new Actor[7];
        numActors = 0;
    }

    private void resize()
    {
        // TODO: write this later
    }

    public void addActor(Actor a)
    {
        resize();
        actors[numActors] = a;
        numActors++;
    }

    public String toString()
    {
        return title + " released on " + releaseDate;
    }
}
