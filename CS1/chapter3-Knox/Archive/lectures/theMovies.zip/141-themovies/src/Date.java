public class Date 
{
    /*
     * Write a class that represents a date. A date contains a year, a month, and a day, and has the following methods:
A Constructor that takes the month, day, and year as parameters, and sets them to instance variables.
A toString() method that returns the date in the format yyyy-mm-dd
A method called isSameDecade() that takes another Date as a parameter, and returns true if the dates are in the same decade, and false otherwise. For example, 1987 and 1981 are the same decade.

     */

     private int year;
     private int month;
     private int day;

     public Date(int y, int m, int d)
     {
        year = y;
        month = m;
        day = d;
     }

     public String toString()
     {
        // yyyy-mm-dd
        String result = "";
        if (year < 1000) {
            result += "0";
        }
        if (year < 100) {
            result += "0";
        }
        if (year < 10) {
            result += "0";
        }
        result += year + "-";
        
        if (month < 10) {
            result += "0";
        }
        result += month + "-";
        
        if (day < 10) {
            result += "0";
        }
        result += day;
        return result;
     }

     public boolean isSameDecade(Date other)
     {
        return year / 10 == other.year / 10;
        /*
        these do the same thing:

        if (year / 10 == other.year / 10)
        {
            return true;
        } else {
            return false;
        }
             */
     }
    

     
}
