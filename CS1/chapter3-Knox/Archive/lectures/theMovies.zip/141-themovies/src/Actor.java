public class Actor 
{
    private String firstName;
    private String lastName;
    private Movie[] movies;
    private int numMovies;

    public Actor(String first, String last)
    {
        firstName = first;
        lastName = last;
        movies = new Movie[5];
        numMovies = 0;
    }

    private void resize()
    {
        if (numMovies == movies.length)
        {
            Movie[] temp = new Movie[numMovies * 2];
            for (int i=0; i<numMovies; i++)
            {
                temp[i] = movies[i];
            }
            movies = temp;
        }
    }
    

    public void addMovie(Movie m)
    {
        if (numMovies == movies.length)
        {
            //System.out.println("resizing when numMovies is " +numMovies);
            Movie[] temp = new Movie[numMovies * 2];
            for (int i=0; i<numMovies; i++)
            {
                temp[i] = movies[i];
            }
            movies = temp;
        }
        movies[numMovies] = m;
        numMovies++;
    }

    public void addMovie2(Movie m)
    {
        resize();
        movies[numMovies] = m;
        numMovies++;
    }

    public String getFullName()
    {
        return firstName + " " + lastName;
    }

    public String toString()
    {
        String result = getFullName() + "\n";
        for (int i=0; i<numMovies; i++) {
            result += movies[i].toString() + "\n";
        }
        return result;
    }

    
}
