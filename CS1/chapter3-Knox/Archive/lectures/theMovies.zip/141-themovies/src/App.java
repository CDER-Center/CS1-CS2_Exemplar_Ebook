public class App {
    public static void main(String[] args) throws Exception {
        Date d1 = new Date(2025, 2, 26);

        Date d2 = new Date(825, 2, 9);

        System.out.println(d1);
        System.out.println(d2.toString());

        System.out.println(d1.isSameDecade(d2));

        System.out.println(d1.isSameDecade(d1));

        Actor a = new Actor("Jackie", "Chan");

        Movie m = new Movie("Rush Hour", new Date(1998, 9, 18));
        a.addMovie(m);

        System.out.println(a);
        System.out.println(m);
    }
}
