import java.awt.Color;

public class Face
{
    public static void main(String[] args)
    {
        // TODO: Draw a face.
        // It can be a smiley face, a frowny face, a winky face, a sad face, etc.
        // A face should have at least 4 features 
        // (mouth, eyes, ears, nose, hair, etc).
        // Be creative!
        System.out.println("\n\nDraw a face\n\n");

        // Your code here:
        
    }
    
}
