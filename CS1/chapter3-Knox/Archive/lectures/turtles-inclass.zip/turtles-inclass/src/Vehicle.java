public class Vehicle
{
    public static void main(String[] args)
    {
        // TODO: Draw a vechicle.
        // It can be a car, truck, bus, bike, spaceship, Tardis, etc.
        // Be creative!
        System.out.println("\n\nDraw a vehicle\n\n");

        // your code here:
        
    }
    
}
