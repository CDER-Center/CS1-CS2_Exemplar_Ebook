

public class StickFig
{
    public static void main(String[] args)
    {
        // TODO: Draw a stick figure.
        // A stick figure has a head, body, arms, and legs.
        // But, you can be creative. Extra arms? Great!
        // Two heads? Awesome.
        System.out.println("\n\nDraw a stick figure\n\n");

        // Your code here

    }
    
}
