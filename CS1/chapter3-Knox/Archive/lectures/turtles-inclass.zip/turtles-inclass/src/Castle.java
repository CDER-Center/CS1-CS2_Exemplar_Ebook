import java.awt.Color;

public class Castle 
{
    public static void main(String[] args)
    {
        int width = 100;
        int height = 800;

        World world = new World(width, height);
        Turtle t = new Turtle(world);

        System.out.println("Turtle is at " + t.getXPos() + ", " + t.getYPos());
        
        //t.setPenColor(Color.GREEN);
        //t.setPenWidth(width);
        //t.setPenWidth(100);
        t.setPenWidth(width/4);
        
        t.forward(height/2);

        System.out.println("Turtle is at " + t.getXPos() + ", " + t.getYPos());

        t.backward(height/2);

        System.out.println("Turtle is at " + t.getXPos() + ", " + t.getYPos());
        
        t.setColor(Color.BLUE);
        t.backward(height/2);

        System.out.println("Turtle is at " + t.getXPos() + ", " + t.getYPos());

        /*
        t.penUp();
        t.moveTo(0, height/4);

        t.turn(90);
        t.penDown();
        t.setPenColor(Color.GREEN);
        t.setPenWidth(height/4);
        t.forward(width);
         */
    }
    
}
