//import java.awt.Color;

public class Jamal {
    public static void main(String[] args)
    {
        World world = new World();
        Turtle jamal = new Turtle(world);
        //jamal.hide();
        //jamal.setColor(Color.BLACK);
        //jamal.setPenWidth(20);
        jamal.forward(100);
        jamal.turn(90);
        jamal.forward(100);
        jamal.turn(-45);
        jamal.forward(100);
    }
    
}
