import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LetterO here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Letter extends Actor
{
    // make sure the images are the same width and height
    GreenfootImage xImage = new GreenfootImage("images/x.png");
    GreenfootImage oImage = new GreenfootImage("images/o.png");
    
    public Letter(char letter) {
        if (letter == 'X' || letter == 'x') {
            setImage(new GreenfootImage(xImage));
        } else if (letter == 'O' || letter == 'o') {
            setImage(new GreenfootImage(oImage));
        }
    }

    public int getWidth() {
        return xImage.getWidth();
    }
    
    public int getHeight() {
        return xImage.getHeight();
    }
    
    /**
     * Act - do whatever the LetterO wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
    }
}
