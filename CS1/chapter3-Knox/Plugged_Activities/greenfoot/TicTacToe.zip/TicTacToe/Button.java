import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class NewGameButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Button extends Actor {
    private GreenfootImage normal;
    private GreenfootImage hovered;

    public Button(String label) {
        setText(label);
        setImage(normal);
    }
    
    public void setText(String label) {
        normal = new GreenfootImage(label, 60, Color.WHITE, Color.BLACK);
        hovered = new GreenfootImage(label, 60, Color.YELLOW, Color.BLACK);
    }

    public void act() {
        if (Greenfoot.mouseMoved(this)) {
            setImage(hovered);
        } else if (Greenfoot.mouseMoved(null)) {
            setImage(normal);
        }

        if (Greenfoot.mouseClicked(this)) {
            onClick();
        }
    }

    public void onClick()
    {
        MyWorld myWorld = (MyWorld)getWorld();
        myWorld.newGame();
    }
}

