
import com.google.gson.*;
import java.lang.reflect.Type;

public class GameState {
    private char[][] grid = new char[3][3];
    private char currentPlayer = 'X';
    private String winner = null;
    private boolean gameOver = false;

    public GameState() {}

    public boolean isGameOver() {
        return gameOver;
    }

    public char getCurrentPlayer() {
        return currentPlayer;
    }
    
    public void setCurrentPlayer(char player) {
        this.currentPlayer = player;
    }

    private char getCell(int row, int col) {
        return grid[row][col];
    }

    private void setCell(int row, int col, char value) {
        grid[row][col] = value;
    }

    public char[][] getGrid() {
        return grid;
    }
    
    public void setGrid(char[][] grid){
        this.grid = grid;
    }
    
    public String getWinner() {
        return winner;
    }
    
    public void setWinner(String winner) {
        this.winner = winner;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        if (gameOver){
            if (winner.equals("Tie")) sb.append("It was a Tie!\n");
            else sb.append("Winner is " +winner+"\n");
        } else {
            sb.append(currentPlayer + " to move\n");
        }
        for (char[] row : grid) {
            for (char cell : row) {
                sb.append(cell).append(" | ");
            }
            sb.setLength(sb.length() - 3); // Remove last " | "
            sb.append("\n");
        }
        return sb.toString();
    }

    public boolean isLegalMove(int r, int c) {
        return r >= 0 && r <= 2 && c >= 0 && c <= 2 && getCell(r, c) == ' ';
    }
    
    public static GameState fromJson(String json) {
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(char[][].class, new CharGridDeserializer())
                .create();
        return gson.fromJson(json, GameState.class);
    }
    
    private static class CharGridDeserializer implements JsonDeserializer<char[][]> 
    {
        @Override
        public char[][] deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                throws JsonParseException 
        {
            JsonArray jsonArray = json.getAsJsonArray();
            char[][] result = new char[jsonArray.size()][];
            for (int i = 0; i < jsonArray.size(); i++) {
                String row = jsonArray.get(i).getAsString();
                result[i] = row.toCharArray();
            }
            return result;
        }
    }
}



