import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    ClientConnector connector;
    String user = "test";
    String url = "http://localhost:8080/tictactoe";
    Button newGame = new Button("New Game");
    Button gameOver;
    
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld() throws Exception
    {    
        // Create a new world with 450x450 cells with a cell size of 1x1 pixels.
        super(450, 650, 1);
        
        // set background image
        // we picked 450x450 because the image is 450x450
        GreenfootImage image = new GreenfootImage("images/grid.png");
        getBackground().drawImage(image, 0, 0);
        
        // the connector for connecting to the game
        connector = new ClientConnector(url, user);
        
        // new game button
        addObject(newGame, 225, 500);
        
        // start a new game
        newGame();
        
    }
    
    public void newGame() 
    {
        connector.newGame();
        removeObjects(getObjects(Letter.class));
        removeObject(gameOver);
    }
    
    public void setLetter(int row, int col, char letter)
    {
        Letter let = new Letter(letter);
        addObject(let, col * 150 + let.getWidth()/2, row * 150 + let.getHeight()/2);
    }
    
    
    public void act()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null) {
            if (Greenfoot.mousePressed(null)) {
                int button = mouse.getButton();
                int row = mouse.getY() / 150;
                int col = mouse.getX() / 150;
                
                //System.out.println("Mouse clicked " + row + ", " + col);
                if (row < 0 || row > 2 || col < 0 || col > 2) return;
                try {
                    GameState state = connector.makeMove(row, col);
                    char[][] grid = state.getGrid();
                    for (int r=0; r<grid.length; r++) {
                        for (int c=0; c<grid[r].length; c++) {
                            if (grid[r][c] != ' ') setLetter(r, c, grid[r][c]);
                        }
                    }
                    //System.out.println(state);
                    if (state.isGameOver()) {
                        String winner = state.getWinner();
                        if (!winner.equals("Tie")) winner = "Winner is " + winner;
                        gameOver = new Button(winner);
                        addObject(gameOver, 225, 600);
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    }
}
