import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

public class ClientConnector 
{
    private final String baseUrl;
    private final String user;
    private final HttpClient client;
    private final String params;
 
    public ClientConnector(String baseUrl, String user) 
    {
        this.baseUrl = baseUrl;
        this.user = user;
        this.client = HttpClient.newHttpClient();
        this.params = "?user=" + user;
    }
    
    // start a new game
    public GameState newGame() 
    {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/newgame" + params))
            .GET()
            .build();
        //System.out.println("Request: " + request);
        try {
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            //String s = response.body();
            //System.out.println(s);
            return GameState.fromJson(response.body());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public GameState makeMove(int row, int col) 
    {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/move" + params + "&row=" + row + "&col=" + col))
            .GET()
            .build();
        //System.out.println("Request: " + request);
        try {
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            return GameState.fromJson(response.body());
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public boolean setAI(String opponent)
    {
        if (!opponent.equals("random") && !opponent.equals("smart")) {
            throw new IllegalArgumentException("AI opponent must be 'random' or 'smart'");
        }
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/ai/" + opponent + params))
            .GET()
            .build();
        try {
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            return true;
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    
}