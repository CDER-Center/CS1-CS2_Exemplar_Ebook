import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    public static final int width = 72;
    public static final int height = 72;
    
    private ClientConnector connector;
    private String url = "http://euclid.knox.edu:8082/connect4";
    String user = "test";
    NewGame newGame = new NewGame();
    GameOver gameOver;
    private Checker[][] grid = new Checker[6][7];
    
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(504, 632, 1);
        
        GreenfootImage image = new GreenfootImage("images/c4grid.png");
        getBackground().drawImage(image, 0, 0);
        
        // the connector for connecting to the game
        connector = new ClientConnector(url, user);
        
        // new game button
        addObject(newGame, 252, 482);
        
        // start a new game
        newGame();
    }
    
    public void newGame()
    {
        System.out.println("new game");
        connector.newGame();
        removeObjects(getObjects(Checker.class));
        removeObject(gameOver);
        grid = new Checker[6][7];
    }
    
    // method you would implement — code not shown
    // public boolean makeMove(int col, String checker)
    
    public void placeChecker(int row, int col, Checker c)
    {
        int x = width/2 + col*width;
        int y = height/2 + row*height;
        System.out.println("placing checker at "+x+", "+y);
        addObject(c, x, y);
    }
    
    public boolean makeMove(int col, String checker)
    {
        // TODO: implement this
        return false;
    }
    
    public void act()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        if (mouse != null) {
            if (Greenfoot.mousePressed(null)) {
                // TODO: implement this
            }
        }
    }
}
