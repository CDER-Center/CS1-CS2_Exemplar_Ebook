import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Checker here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Checker extends Actor
{
    
    public Checker(String color) {
        if (color.equalsIgnoreCase("yellow")) {
            setImage(new GreenfootImage("images/yellow-checker.png"));
        } else if (color.equalsIgnoreCase("red")){
            setImage(new GreenfootImage("images/red-checker.png"));
        } else {
            throw new IllegalArgumentException("Illegal checker color "+color);
        }
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
