import java.util.List;
import com.google.gson.*;

public class C4GameState 
{
    // current player
    // most recent move
    // move list
    // is game over?
    // winner?

    private Move[] moves;
    private String currentPlayer;
    private int lastMoveColumn;
    private boolean gameOver;
    private String winner;
    

    public Move[] getMoves() {
        return moves;
    }
    public String getCurrentPlayer() {
        return currentPlayer;
    }
    public int getLastMoveColumn() {
        return lastMoveColumn;
    }
    public boolean isGameOver() {
        return gameOver;
    }
    public String getWinner() {
        return winner;
    }
    
    public void setMoves(Move[] moves){
        this.moves = moves;
    }
    public void setCurrentPlayer(String player){
        this.currentPlayer = player;
    }
    public void setLastMoveColumn(int col){
        this.lastMoveColumn = col;
    }
    public void setGameOver(boolean gameOver){
        this.gameOver = gameOver;
    }
    public void setWinner(String winner){
        this.winner = winner;
    }
    
    public static C4GameState fromJson(String json) {
        Gson gson = new GsonBuilder().create();
        return gson.fromJson(json, C4GameState.class);
    }
    
}
