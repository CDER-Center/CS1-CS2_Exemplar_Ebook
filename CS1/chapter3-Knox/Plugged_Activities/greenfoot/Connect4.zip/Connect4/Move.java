/**
 * Write a description of class Move here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Move  
{
    private String player;
    private int col;
    
    public void setPlayer(String player){
        this.player = player;
    }
    public void setCol(int col){
        this.col = col;
    }
    public int getCol(){
        return col;
    }
    public String getPlayer() {
        return player;
    }
    
    
}
