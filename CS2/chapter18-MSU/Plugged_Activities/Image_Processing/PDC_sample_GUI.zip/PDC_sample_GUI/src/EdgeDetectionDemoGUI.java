import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;

public class EdgeDetectionDemoGUI extends JFrame {

    private final JComboBox<String> modeBox;
    private final JSpinner threadsSpinner;
    private final JLabel coresLabel;   // shows logical cores
    private final JLabel noteLabel;    // warns when threads > cores
    private final JButton runBtn;
    private final JLabel statusLabel;
    private final JLabel timeLabel;
    private final JLabel processedLabel;
    private final JTextArea logArea;
    private final DefaultTableModel historyModel;

    private final File inputDir  = new File("images/input");
    private final File outputDir = new File("images/output");

    public EdgeDetectionDemoGUI() {
        super("Edge Detection — Sequential vs Parallel");

        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());

        // Controls
        modeBox = new JComboBox<>(new String[]{"Sequential", "Parallel"});

        // Unbounded (practically) threads; user can type any large value
        threadsSpinner = new JSpinner(new SpinnerNumberModel(Math.max(2, cores), 1, Integer.MAX_VALUE, 1));
        ((JSpinner.NumberEditor)threadsSpinner.getEditor()).getTextField().setColumns(6);

        runBtn = new JButton("Run");

        // Top controls layout
        JPanel controls = new JPanel(new GridBagLayout());
        controls.setBorder(new EmptyBorder(12, 12, 8, 12));
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(0, 6, 0, 6);
        gc.gridy = 0;

        gc.gridx = 0; controls.add(new JLabel("Mode:"), gc);
        gc.gridx = 1; controls.add(modeBox, gc);
        gc.gridx = 2; controls.add(new JLabel("Threads:"), gc);
        gc.gridx = 3; controls.add(threadsSpinner, gc);
        gc.gridx = 4; controls.add(runBtn, gc);

        // Cores + note line
        coresLabel = new JLabel("Logical cores: " + cores);
        noteLabel = new JLabel(" ");
        noteLabel.setForeground(new Color(180, 80, 0));
        JPanel notePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        notePanel.add(coresLabel);
        notePanel.add(noteLabel);

        // Stats strip
        statusLabel = new JLabel("Idle");
        timeLabel = new JLabel("Time: —");
        processedLabel = new JLabel("Processed: —");
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        stats.setBorder(new EmptyBorder(0, 12, 0, 12));
        stats.add(statusLabel);
        stats.add(timeLabel);
        stats.add(processedLabel);

        // Log area
        logArea = new JTextArea(14, 90);
        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(new EmptyBorder(4, 12, 12, 12));

        // History table
        historyModel = new DefaultTableModel(new String[]{
                "Timestamp", "Mode", "Threads", "Images", "Seconds"
        }, 0);
        JTable historyTable = new JTable(historyModel);
        historyTable.setFillsViewportHeight(true);
        JScrollPane tableScroll = new JScrollPane(historyTable);
        tableScroll.setBorder(new EmptyBorder(0, 12, 12, 12));
        tableScroll.setPreferredSize(new Dimension(900, 140));

        // Layout
        setLayout(new BorderLayout());
        add(controls, BorderLayout.NORTH);

        JPanel mid = new JPanel(new BorderLayout());
        mid.add(notePanel, BorderLayout.NORTH);
        mid.add(stats, BorderLayout.CENTER);
        add(mid, BorderLayout.CENTER);

        JPanel south = new JPanel(new BorderLayout());
        south.add(tableScroll, BorderLayout.NORTH);
        south.add(logScroll, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        // Behavior
        modeBox.addActionListener(e -> threadsSpinner.setEnabled(isParallelSelected()));
        threadsSpinner.setEnabled(isParallelSelected());
        threadsSpinner.addChangeListener(e -> {
            if (isParallelSelected() && ((Number)threadsSpinner.getValue()).intValue() > cores) {
                noteLabel.setText("Threads exceed core count: overhead/slowdown likely at very high values.");
            } else {
                noteLabel.setText(" ");
            }
        });

        runBtn.addActionListener(this::onRunClicked);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
    }

    private boolean isParallelSelected() {
        return "Parallel".equals(modeBox.getSelectedItem());
    }

    private void onRunClicked(ActionEvent e) {
        runBtn.setEnabled(false);
        logArea.setText("");
        statusLabel.setText("Validating folders…");
        timeLabel.setText("Time: —");
        processedLabel.setText("Processed: —");

        if (!inputDir.isDirectory()) {
            JOptionPane.showMessageDialog(this,
                    "Input folder not found:\n" + inputDir.getAbsolutePath(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            runBtn.setEnabled(true);
            statusLabel.setText("Error");
            return;
        }
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            JOptionPane.showMessageDialog(this,
                    "Could not create output folder:\n" + outputDir.getAbsolutePath(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            runBtn.setEnabled(true);
            statusLabel.setText("Error");
            return;
        }

        final boolean useParallel = isParallelSelected();
        final int threads = ((Number)threadsSpinner.getValue()).intValue();

        new SwingWorker<Result, String>() {
            @Override
            protected Result doInBackground() {
                // Correct start message: only show threads for Parallel
                String startMsg = useParallel
                        ? "Starting parallel batch… (threads=" + threads + ")"
                        : "Starting sequential batch…";
                publish(startMsg);

                long start = System.nanoTime();
                try {
                    if (useParallel) {
                        int images = processParallel(inputDir, outputDir, threads, this::publish);
                        double seconds = (System.nanoTime() - start) / 1_000_000_000.0;
                        return new Result(images, seconds, null);
                    } else {
                        int images = processSequential(inputDir, outputDir, this::publish);
                        double seconds = (System.nanoTime() - start) / 1_000_000_000.0;
                        return new Result(images, seconds, null);
                    }
                } catch (Exception ex) {
                    return new Result(0, 0.0, ex);
                }
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                for (String s : chunks) logArea.append(s + "\n");
            }

            @Override
            protected void done() {
                try {
                    Result r = get();
                    if (r.error != null) {
                        statusLabel.setText("Failed");
                        JOptionPane.showMessageDialog(EdgeDetectionDemoGUI.this,
                                "Error: " + r.error.getMessage(),
                                "Execution Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        statusLabel.setText("Done");
                        processedLabel.setText("Processed: " + r.images);
                        timeLabel.setText(String.format("Time: %.3f s", r.seconds));
                        historyModel.addRow(new Object[]{
                                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                                isParallelSelected() ? "Parallel" : "Sequential",
                                isParallelSelected() ? threadsSpinner.getValue() : 1,
                                r.images,
                                String.format("%.3f", r.seconds)
                        });
                        logArea.append(String.format("\nCompleted. %d image(s) in %.3f s\n",
                                r.images, r.seconds));
                        /*if (isParallelSelected()) {
                            logArea.append("\nTip: Very high thread counts can cause slowdown due to scheduling,\n" +
                                    "context switching, memory bandwidth limits, and cache contention.\n");
                        } */
                    }
                } catch (Exception ex) {
                    statusLabel.setText("Failed");
                    JOptionPane.showMessageDialog(EdgeDetectionDemoGUI.this,
                            "Error: " + ex.getMessage(),
                            "Execution Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    runBtn.setEnabled(true);
                }
            }
        }.execute();
    }

    // ----------------------- Processing (Sequential) -----------------------

    private int processSequential(File inDir, File outDir, java.util.function.Consumer<String> log) throws IOException {
        File[] files = listImages(inDir);
        if (files.length == 0) {
            log.accept("No input images found in " + inDir.getAbsolutePath());
            return 0;
        }
        int processed = 0;
        for (File f : files) {
            BufferedImage input = ImageIO.read(f);
            if (input == null) {
                log.accept("Skip (unreadable): " + f.getName());
                continue;
            }
            int width = input.getWidth();
            int height = input.getHeight();
            BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            for (int y = 1; y < height - 1; y++) {
                for (int x = 1; x < width - 1; x++) {
                    output.setRGB(x, y, computeEdgePixel(input, x, y));
                }
            }

            File outFile = new File(outDir, baseName(f.getName()) + "_edges_seq.jpg");
            ImageIO.write(output, "jpg", outFile);
            log.accept("Wrote: " + outFile.getPath());
            processed++;
        }
        return processed;
    }

    // ----------------------- Processing (Parallel) -----------------------

    private int processParallel(File inDir, File outDir, int numThreads,
                                java.util.function.Consumer<String> log)
            throws IOException, InterruptedException {

        File[] files = listImages(inDir);
        if (files.length == 0) {
            log.accept("No input images found in " + inDir.getAbsolutePath());
            return 0;
        }
        int processed = 0;

        for (File f : files) {
            BufferedImage input = ImageIO.read(f);
            if (input == null) {
                log.accept("Skip (unreadable): " + f.getName());
                continue;
            }

            int width = input.getWidth();
            int height = input.getHeight();
            BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            // Fixed thread pool with user-specified size (can be VERY large)
            ExecutorService exec = Executors.newFixedThreadPool(numThreads);
            CountDownLatch latch = new CountDownLatch(Math.max(0, height - 2));

            // Striped locks to reduce contention
            Object[] pixelLocks = new Object[(width * height) / 64 + 1];
            for (int i = 0; i < pixelLocks.length; i++) pixelLocks[i] = new Object();

            for (int y = 1; y < height - 1; y++) {
                final int row = y;
                exec.submit(() -> {
                    try {
                        for (int x = 1; x < width - 1; x++) {
                            int edgeRgb = computeEdgePixel(input, x, row);
                            int lockIndex = (row * width + x) / 64;
                            synchronized (pixelLocks[lockIndex]) {
                                int existingRgb = output.getRGB(x, row);
                                int combinedRgb = combineRgb(existingRgb, edgeRgb);
                                output.setRGB(x, row, combinedRgb);
                            }
                        }
                    } finally {
                        latch.countDown();
                    }
                });
            }

            latch.await();
            exec.shutdown();

            File outFile = new File(outDir, baseName(f.getName()) + "_edges_par_t" + numThreads + ".jpg");
            ImageIO.write(output, "jpg", outFile);
            log.accept("Wrote: " + outFile.getPath());
            processed++;
        }
        return processed;
    }

    // ----------------------- Helpers & Sobel -----------------------

    private static File[] listImages(File dir) {
        File[] files = dir.listFiles((d, name) -> {
            String n = name.toLowerCase();
            return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") || n.endsWith(".bmp");
        });
        return files == null ? new File[0] : files;
    }

    private static String baseName(String name) {
        int dot = name.lastIndexOf('.');
        return (dot > 0) ? name.substring(0, dot) : name;
    }

    private static int computeEdgePixel(BufferedImage img, int x, int y) {
        int[][] gx = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
        int[][] gy = {{ 1, 2, 1}, { 0, 0, 0}, {-1,-2,-1}};
        int sumX = 0, sumY = 0;

        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int rgb = img.getRGB(x + j, y + i);
                int gray = rgbToGray(rgb);
                sumX += gx[i + 1][j + 1] * gray;
                sumY += gy[i + 1][j + 1] * gray;
            }
        }
        int magnitude = Math.min(255, (int) Math.sqrt(sumX * sumX + sumY * sumY));
        return (magnitude << 16) | (magnitude << 8) | magnitude;
    }

    private static int combineRgb(int existingRgb, int newRgb) {
        int existingGray = existingRgb & 0xff;
        int newGray = newRgb & 0xff;
        int combinedGray = Math.min(255, existingGray + newGray);
        return (combinedGray << 16) | (combinedGray << 8) | combinedGray;
    }

    private static int rgbToGray(int rgb) {
        int r = (rgb >> 16) & 0xff;
        int g = (rgb >> 8) & 0xff;
        int b = rgb & 0xff;
        return (r + g + b) / 3;
    }

    private record Result(int images, double seconds, Exception error) {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EdgeDetectionDemoGUI().setVisible(true));
    }
}
