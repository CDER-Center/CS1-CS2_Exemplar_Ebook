import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EdgeDetectionParallel {
    public static void main(String[] args) throws IOException, InterruptedException {
        String path = "images/input/";
        String outputPath = "images/output/";
        String fileName = "aroma.jpg";


        BufferedImage inputImage = ImageIO.read(new File(path + fileName));
        int width = inputImage.getWidth();
        int height = inputImage.getHeight();
        BufferedImage outputImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        int numberThread = 8;
        ExecutorService executor = Executors.newFixedThreadPool(numberThread);
        CountDownLatch latch = new CountDownLatch(height - 2);

        // start timer
        long startTime = System.nanoTime();

        for (int y = 1; y < height - 1; y++) {
            final int row = y;
            executor.submit (() -> {
                for (int x = 1; x < width - 1; x++) {
                    int edgeRgb = computeEdgePixel(inputImage, x, row);
                    outputImage.setRGB(x, row, edgeRgb);
                }
                latch.countDown();
            });
        }

        latch.await();
        executor.shutdown();

        // end timer
        long endTime = System.nanoTime();
        long durationMs = (endTime - startTime) / 1_000_000;

        System.out.println("Execution time: " + durationMs + " ms");

        ImageIO.write(outputImage, "jpg", new File(outputPath + "image_edges_parallel.jpg"));
    }

    private static int computeEdgePixel(BufferedImage img, int x, int y) {
        int[][] gx = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
        int[][] gy = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};

        int sumX = 0, sumY = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int gray = rgbToGray(img.getRGB(x + j, y + i));
                sumX += gx[i + 1][j + 1] * gray;
                sumY += gy[i + 1][j + 1] * gray;
            }
        }

        int magnitude = Math.min(255, (int) Math.sqrt(sumX * sumX + sumY * sumY));
        return (magnitude << 16) | (magnitude << 8) | magnitude;
    }

    private static int rgbToGray(int rgb) {
        int r = (rgb >> 16) & 0xff;
        int g = (rgb >> 8) & 0xff;
        int b = rgb & 0xff;
        return (r + g + b) / 3;
    }
}
