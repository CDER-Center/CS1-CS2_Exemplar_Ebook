import java.util.*;

public class Timing {   //object that performs timing tests
	private String[] data;  //array of strings for use in our tests

	public Timing(int numStr) {

		this.data = new String[numStr];

		for (int i = 0; i < data.length; ++i) {
			this.data[i] = "word" + i;
		}
	}
	
	public void timeArrayList() {
		//put code for array list operations here...
	}

	public static void main(String[] args) {
		int n = 25000;
		Timing tester = new Timing(n);
		System.out.println("NEW RUN: n = " + n);
		
		tester.timeArrayList();
	}
}
