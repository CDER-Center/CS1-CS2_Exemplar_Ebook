public class QueryCount {
    
    public static void main(String[] args) {
        
    }
}
