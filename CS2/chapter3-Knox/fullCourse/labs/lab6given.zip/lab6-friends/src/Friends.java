import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Friends {
	
	public Friends(Scanner input) {
		while(input.hasNext())  {  //while there is more input
			//read from input using input.next(), which returns the next input word
		}
	}
	
	public static final String filename = "smallNetwork";  //name of the file to read from
	
	public static void main(String[] args) {
		Scanner input = null;
		try {
			input = new Scanner(new File(filename));
		} catch(FileNotFoundException ex) {
			System.err.println("Unable to find input file: " + filename);
			System.exit(1);
		}
		
		Friends f = new Friends(input);   //create object to represent the network
	}
}
