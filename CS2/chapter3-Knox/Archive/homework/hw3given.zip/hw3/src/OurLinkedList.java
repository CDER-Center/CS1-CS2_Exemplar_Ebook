public class OurLinkedList< T> {

    private Node head;

    public class Node {
        public T value;
        public Node next;

        public Node(T value, Node next) {
            this.value = value;
            this.next = next;
        }
    }

    public void addFront(T newItem) {
        Node newNode = new Node(newItem, head);
        head = newNode;
    }

    public T get(int index) {
        //return value at given index or throw IndexOutOfBoundsException
        //as written, this is close, but doesn't work in all cases

        int num = 0;  //index of current node
        Node curr = head;
        while(num < index) {
            curr = curr.next;
            num++;
        }
        return curr.value;
    }
}
