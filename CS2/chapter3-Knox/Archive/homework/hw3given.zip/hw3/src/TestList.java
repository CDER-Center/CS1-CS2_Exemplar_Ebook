import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestList {
    
    OurLinkedList< String> list;

    @Before
    public void setup() {
       list = new OurLinkedList< String>();
    }

    @Test
    public void test1() {
    }
}
