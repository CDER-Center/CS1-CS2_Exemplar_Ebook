import cv2

# Read the image
image = cv2.imread('input.jpg')  # Replace with your image filename

# Check if the image was loaded successfully
if image is None:
    print("Error: Image not found.")
    exit()

# Apply Gaussian blur
blurred = cv2.GaussianBlur(image, (15, 15), 0)

# Display the original and blurred images
cv2.imshow('Original Image', image)
cv2.imshow('Blurred Image', blurred)

# Save the blurred image
cv2.imwrite('blurred_output.jpg', blurred)

# Wait until a key is pressed, then close windows
cv2.waitKey(0)
cv2.destroyAllWindows()
