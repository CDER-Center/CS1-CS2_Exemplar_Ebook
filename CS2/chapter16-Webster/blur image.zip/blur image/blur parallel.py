import cv2
import numpy as np
from multiprocessing import Pool, cpu_count

def blur_section(section):
    """Apply Gaussian blur to a section of the image."""
    return cv2.GaussianBlur(section, (15, 15), 0)

def parallel_blur(image_path, num_workers=None):
    # Read the image
    image = cv2.imread(image_path)
    if image is None:
        print("Error: Could not load image.")
        return None

    # Determine number of processes
    if num_workers is None:
        num_workers = cpu_count()

    # Split the image into vertical sections
    h = image.shape[0]
    sections = np.array_split(image, num_workers, axis=0)

    # Process each section in parallel
    with Pool(processes=num_workers) as pool:
        blurred_sections = pool.map(blur_section, sections)

    # Recombine the blurred sections
    blurred_image = np.vstack(blurred_sections)
    return blurred_image

if __name__ == "__main__":
    input_image = "input.jpg"
    output_image = "blurred_parallel.jpg"

    blurred = parallel_blur(input_image)
    if blurred is not None:
        cv2.imwrite(output_image, blurred)
        cv2.imshow("Blurred Image", blurred)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
