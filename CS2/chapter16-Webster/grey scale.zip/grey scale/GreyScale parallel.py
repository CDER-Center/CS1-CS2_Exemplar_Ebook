import cv2
import numpy as np
from multiprocessing import Pool, cpu_count

def to_grayscale(section):
    """Convert a section of the image to grayscale."""
    return cv2.cvtColor(section, cv2.COLOR_BGR2GRAY)

def parallel_grayscale(image_path, num_workers=None):
    # Read the image
    image = cv2.imread(image_path)
    cv2.imshow("Grayscale Image (Parallel)", image)
    if image is None:
        print("Error: Could not load image.")
        return None

    # Determine number of processes
    if num_workers is None:
        num_workers = cpu_count()

    # Split the image into sections (rows)
    h = image.shape[0]
    sections = np.array_split(image, num_workers, axis=0)

    # Parallel processing
    with Pool(processes=num_workers) as pool:
        gray_sections = pool.map(to_grayscale, sections)

    # Recombine the sections
    gray_image = np.vstack(gray_sections)
    return gray_image

if __name__ == "__main__":
    input_image = "input.jpg"
    output_image = "gray_parallel.jpg"
    image = cv2.imread(input_image)
    cv2.imshow("Grayscale Image (Parallel)", image)
    gray = parallel_grayscale(input_image)
    if gray is not None:
        cv2.imwrite(output_image, gray)
        cv2.imshow("Grayscale Image (Parallel)", gray)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
