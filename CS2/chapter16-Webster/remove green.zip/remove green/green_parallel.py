import cv2 #pip install opencv-python
import numpy as np
import multiprocessing as mp

# Define green screen removal function
def remove_green(chunk):
    """Process a chunk of the image to remove green background."""
    hsv = cv2.cvtColor(chunk, cv2.COLOR_BGR2HSV)
    lower_green = np.array([35, 40, 40])
    upper_green = np.array([85, 255, 255])
    mask = cv2.inRange(hsv, lower_green, upper_green)
    mask_inv = cv2.bitwise_not(mask)
    result = cv2.bitwise_and(chunk, chunk, mask=mask_inv)
    return result

def parallel_remove_green(image, num_workers=4):
    """Split image into vertical chunks and process in parallel."""
    height = 0
    chunk_size = 1
    if image is not None:
        height = image.shape[0]
        chunk_size = height // num_workers

        # Split into chunks
        chunks = [image[i*chunk_size:(i+1)*chunk_size] for i in range(num_workers)]

        # Use multiprocessing pool
        with mp.Pool(processes=num_workers) as pool:
            results = pool.map(remove_green, chunks)

    # Concatenate back into one image
    return np.vstack(results)

if __name__ == "__main__":
    image = cv2.imread("input.jpg")
    result = parallel_remove_green(image, num_workers=mp.cpu_count())

    # Save and show
    cv2.imwrite("output_parallel.png", result)
    cv2.imshow("Original", image)
    cv2.imshow("No Green Background (Parallel)", result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
