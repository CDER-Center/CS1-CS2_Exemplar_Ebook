import cv2  #openCV is aleady vectorized
#pip install opencv-python
import numpy as np

# Load input image
image = cv2.imread("input.jpg")

# Convert to HSV (Hue, Saturation, Value) color space
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Define range for green color in HSV
lower_green = np.array([35, 40, 40])   # adjust as needed
upper_green = np.array([85, 255, 255])

# Create mask where green pixels are 1
mask = cv2.inRange(hsv, lower_green, upper_green)

# Invert mask to keep non-green regions
mask_inv = cv2.bitwise_not(mask)

# Apply mask to keep only foreground
result = cv2.bitwise_and(image, image, mask=mask_inv)

# Save and display
cv2.imwrite("output.png", result)

cv2.imshow("Original", image)
cv2.imshow("No Green Background", result)
cv2.waitKey(0)
cv2.destroyAllWindows()
