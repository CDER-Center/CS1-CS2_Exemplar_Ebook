
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * BoxBlurSeq
 * - Applies a 3x3 box blur (simple average blur) sequentially.
 * - Use this as your baseline for parallelization.
 */
public class BoxBlurSeq {
    public static void main(String[] args) throws IOException {
        String path = "images/input/";
        String outputPath = "images/output/";
        String fileName = args.length > 0 ? args[0] : "aroma.jpg";

        BufferedImage inputImage = ImageIO.read(new File(path + fileName));
        int width = inputImage.getWidth();
        int height = inputImage.getHeight();
        BufferedImage outputImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        long startTime = System.nanoTime();

        // Skip the outer 1px border for simplicity
        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                int blurred = computeBlurPixel(inputImage, x, y);
                outputImage.setRGB(x, y, blurred);
            }
        }

        long endTime = System.nanoTime();
        long durationMs = (endTime - startTime) / 1_000_000;
        System.out.println("BoxBlurSeq time: " + durationMs + " ms");

        new File(outputPath).mkdirs();
        ImageIO.write(outputImage, "jpg", new File(outputPath + "image_blur_seq.jpg"));
    }

    // 3x3 box blur kernel (all weights = 1/9). We work in RGB directly.
    private static int computeBlurPixel(BufferedImage img, int x, int y) {
        int sumR = 0, sumG = 0, sumB = 0;

        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                int rgb = img.getRGB(x + dx, y + dy);
                int r = (rgb >> 16) & 0xff;
                int g = (rgb >> 8) & 0xff;
                int b = rgb & 0xff;
                sumR += r;
                sumG += g;
                sumB += b;
            }
        }

        int r = sumR / 9;
        int g = sumG / 9;
        int b = sumB / 9;

        return (r << 16) | (g << 8) | b;
    }
}
