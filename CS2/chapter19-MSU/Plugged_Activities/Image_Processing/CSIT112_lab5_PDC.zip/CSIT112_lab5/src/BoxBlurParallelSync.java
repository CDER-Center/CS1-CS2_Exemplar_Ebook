

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * BoxBlurParallelSync (WITH synchronization)
 * - Same as BoxBlurParallel, but wrap writes to the shared BufferedImage
 *   in a synchronized block to ensure thread-safety.
 *
 * TODOs marked below.
 */
public class BoxBlurParallelSync {
    public static void main(String[] args) throws IOException, InterruptedException {
        String path = "images/input/";
        String outputPath = "images/output/";
        String fileName = args.length > 0 ? args[0] : "aroma.jpg";

        BufferedImage inputImage = ImageIO.read(new File(path + fileName));
        int width = inputImage.getWidth();
        int height = inputImage.getHeight();
        BufferedImage outputImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        int numberThreads = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(numberThreads);
        CountDownLatch latch = new CountDownLatch(Math.max(0, height - 2));

        long startTime = System.nanoTime();

        // TODO: submit tasks that each process one row y in [1, height-2]


        long endTime = System.nanoTime();
        long durationMs = (endTime - startTime) / 1_000_000;
        System.out.println("BoxBlurParallelSync (with sync) time: " + durationMs + " ms");

        new File(outputPath).mkdirs();
        ImageIO.write(outputImage, "jpg", new File(outputPath + "image_blur_parallel_sync.jpg"));
    }

    private static int computeBlurPixel(BufferedImage img, int x, int y) {
        int sumR = 0, sumG = 0, sumB = 0;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                int rgb = img.getRGB(x + dx, y + dy);
                int r = (rgb >> 16) & 0xff;
                int g = (rgb >> 8) & 0xff;
                int b = rgb & 0xff;
                sumR += r; sumG += g; sumB += b;
            }
        }
        int r = sumR / 9, g = sumG / 9, b = sumB / 9;
        return (r << 16) | (g << 8) | b;
    }
}
