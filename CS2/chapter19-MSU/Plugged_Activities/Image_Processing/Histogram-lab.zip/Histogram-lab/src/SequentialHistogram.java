import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Variant 1: SEQUENTIAL HISTOGRAM (baseline).
 *
 * Counts how many pixels fall into each of 256 brightness (luminance)
 * bins. One thread, one pass, nothing can go wrong: the total of all
 * bins always equals the number of pixels.
 *
 * The printed bin total and checksum are the reference the parallel
 * variants must reproduce.
 *
 * Requires JDK 8+.
 */
public class SequentialHistogram {

    public static void main(String[] args) throws Exception {
        String name = args.length > 0 ? args[0] : "aroma.jpg";
        BufferedImage img = ImageIO.read(new File("images/input/" + name));
        int w = img.getWidth(), h = img.getHeight();
        int[] pixels = img.getRGB(0, 0, w, h, null, 0, w);

        long[] hist = new long[256];   // hist[v] = number of pixels with brightness v

        long start = System.nanoTime();
        for (int i = 0; i < pixels.length; i++) {
            hist[brightness(pixels[i])]++;
        }
        long ms = (System.nanoTime() - start) / 1_000_000;

        System.out.println("=== Sequential histogram ===");
        System.out.println("Image: " + name + " (" + w + "x" + h + ", "
                + (w * h) + " pixels)");
        System.out.println("Time: " + ms + " ms");
        System.out.println("Sum of all bins: " + sum(hist)
                + "   (must equal the pixel count)");
        System.out.println("Bin checksum:    " + checksum(hist));
        printPeaks(hist);

        File chart = new File("images/output/histogram_sequential.png");
        drawHistogram(hist, null, "Sequential histogram", chart);
        System.out.println("Wrote " + chart.getPath());
    }

    /**
     * Render the histogram as a bar chart. Each bar is drawn in the gray
     * level of its own bin, so the x-axis doubles as a brightness ramp.
     * If a reference histogram is given, its outline is drawn as a red
     * line on top -- any gap between the red line and the bar tops means
     * the two histograms disagree.
     */
    static void drawHistogram(long[] hist, long[] reference, String title,
                              File file) throws Exception {
        final int barW = 4, chartH = 400, marginL = 60, marginR = 20,
                  marginT = 50, marginB = 40;
        int width = 256 * barW + marginL + marginR;
        int height = chartH + marginT + marginB;
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();

        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);
        g.setColor(new Color(225, 232, 240));                 // plot background
        g.fillRect(marginL, marginT, 256 * barW, chartH);

        long max = 1;
        for (long v : hist) max = Math.max(max, v);
        if (reference != null)
            for (long v : reference) max = Math.max(max, v);

        for (int i = 0; i < 256; i++) {                       // bars
            int barH = (int) (hist[i] * chartH / max);
            g.setColor(new Color(i, i, i));
            g.fillRect(marginL + i * barW, marginT + chartH - barH, barW, barH);
        }

        if (reference != null) {
            // Solid red fill for the DEFICIT: counts the correct histogram
            // has but this one is missing. Red caps on bars = lost updates.
            g.setColor(Color.RED);
            for (int i = 0; i < 256; i++) {
                int barH = (int) (hist[i] * chartH / max);
                int refH = (int) (reference[i] * chartH / max);
                if (refH > barH) {
                    g.fillRect(marginL + i * barW, marginT + chartH - refH,
                               barW, refH - barH);
                }
            }
        }

        g.setColor(Color.BLACK);                              // frame + labels
        g.drawRect(marginL, marginT, 256 * barW, chartH);
        g.setFont(new Font("SansSerif", Font.BOLD, 18));
        g.drawString(title, marginL, 30);
        g.setFont(new Font("SansSerif", Font.PLAIN, 13));
        g.drawString("0", marginL - 4, marginT + chartH + 18);
        g.drawString("128", marginL + 128 * barW - 12, marginT + chartH + 18);
        g.drawString("255", marginL + 255 * barW - 12, marginT + chartH + 18);
        g.drawString("brightness", marginL + 128 * barW - 35, marginT + chartH + 34);
        g.drawString(String.format("max %,d", max), marginL + 4, marginT - 6);
        if (reference != null) {
            g.setColor(Color.RED);
            g.drawString("red = counts missing vs. correct (sequential) result",
                    marginL + 350, marginT - 6);
        }
        g.dispose();

        file.getParentFile().mkdirs();
        ImageIO.write(img, "png", file);
    }

    /** Brightness (luminance) of an RGB pixel, 0..255. */
    static int brightness(int rgb) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return (299 * r + 587 * g + 114 * b) / 1000;
    }

    static long sum(long[] hist) {
        long s = 0;
        for (long v : hist) s += v;
        return s;
    }

    /** Position-weighted checksum: differs if ANY bin has the wrong count. */
    static long checksum(long[] hist) {
        long s = 0;
        for (int i = 0; i < hist.length; i++) s += (i + 1) * hist[i];
        return s;
    }

    /** Print the five fullest bins, as a quick fingerprint of the result. */
    static void printPeaks(long[] hist) {
        System.out.println("Largest bins:");
        long[] copy = hist.clone();
        for (int k = 0; k < 5; k++) {
            int best = 0;
            for (int i = 1; i < 256; i++) if (copy[i] > copy[best]) best = i;
            System.out.printf("  brightness %3d : %,d pixels%n", best, copy[best]);
            copy[best] = -1;
        }
    }
}
