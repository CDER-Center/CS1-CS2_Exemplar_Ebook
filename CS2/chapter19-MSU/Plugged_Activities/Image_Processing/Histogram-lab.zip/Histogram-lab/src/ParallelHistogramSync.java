import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Variant 3: PARALLEL HISTOGRAM, WITH SYNCHRONIZATION (correct).
 *
 * Same strip-per-task structure, but every update of the shared 256-bin
 * array is protected by a synchronized block on a single lock object.
 * Only one thread at a time can execute hist[v]++, so the read-modify-
 * write can no longer interleave and no count is ever lost. The bin
 * totals match the sequential baseline exactly.
 *
 * MEASURE THE PRICE: the lock is acquired once PER PIXEL, millions of
 * times, and every thread queues on the same lock. Expect this to run
 * SLOWER than the sequential version -- correctness restored, speedup
 * destroyed. That is not a bug in this program; it is the honest cost
 * of fine-grained locking on a hot shared structure.
 *
 * The fast correct alternative (shown in DataParallelismDemo) is to give
 * each task a PRIVATE long[256], count without any locking, and merge
 * the private histograms into the shared one inside a synchronized block
 * once per task -- a handful of lock acquisitions instead of millions.
 *
 * Requires JDK 8+.
 */
public class ParallelHistogramSync {

    // Shared bins, but every update happens inside synchronized(lock).
    static final long[] hist = new long[256];
    static final Object lock = new Object();

    public static void main(String[] args) throws Exception {
        String name = args.length > 0 ? args[0] : "aroma.jpg";
        BufferedImage img = ImageIO.read(new File("images/input/" + name));
        int w = img.getWidth(), h = img.getHeight();
        final int[] pixels = img.getRGB(0, 0, w, h, null, 0, w);

        // Correct reference, computed sequentially, for self-verification.
        long refStart = System.nanoTime();
        long[] reference = new long[256];
        for (int i = 0; i < pixels.length; i++) reference[brightness(pixels[i])]++;
        long refMs = (System.nanoTime() - refStart) / 1_000_000;

        int threads = Runtime.getRuntime().availableProcessors();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch done = new CountDownLatch(threads);
        int rowsPerTask = (h + threads - 1) / threads;

        long start = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            final int y0 = t * rowsPerTask;
            final int y1 = Math.min(h, y0 + rowsPerTask);
            pool.submit(() -> {
                try {
                    for (int y = y0; y < y1; y++) {
                        for (int x = 0; x < w; x++) {
                            int v = brightness(pixels[y * w + x]);
                            synchronized (lock) {   // protects the bin update
                                hist[v]++;
                            }
                        }
                    }
                } finally {
                    done.countDown();
                }
            });
        }
        done.await();
        long ms = (System.nanoTime() - start) / 1_000_000;
        pool.shutdown();

        boolean correct = java.util.Arrays.equals(hist, reference);
        System.out.println("=== Parallel histogram, WITH synchronization ("
                + threads + " threads) ===");
        System.out.println("Image: " + name + " (" + w + "x" + h + ", "
                + (w * h) + " pixels)");
        System.out.println("Sequential reference time: " + refMs + " ms");
        System.out.println("Parallel time:             " + ms
                + " ms   (slower than sequential -- one lock per pixel!)");
        System.out.println("Sum of all bins: " + sum(hist)
                + "   (must equal the pixel count)");
        System.out.println("Bin checksum:    " + checksum(hist));
        System.out.println("All 256 bins match the sequential reference: "
                + (correct ? "yes" : "NO"));

        // Chart with the correct counts overlaid in red: the red line should
        // sit exactly on every bar top, proving the histograms agree.
        File chart = new File("images/output/histogram_sync.png");
        SequentialHistogram.drawHistogram(hist, reference,
                "Parallel histogram, WITH synchronization (" + threads
                + " threads) -- all bins correct", chart);
        System.out.println("Wrote " + chart.getPath());
    }

    /** Brightness (luminance) of an RGB pixel, 0..255. */
    static int brightness(int rgb) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return (299 * r + 587 * g + 114 * b) / 1000;
    }

    static long sum(long[] hist) {
        long s = 0;
        for (long v : hist) s += v;
        return s;
    }

    /** Position-weighted checksum: differs if ANY bin has the wrong count. */
    static long checksum(long[] hist) {
        long s = 0;
        for (int i = 0; i < hist.length; i++) s += (i + 1) * hist[i];
        return s;
    }
}
