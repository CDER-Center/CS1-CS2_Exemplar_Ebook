import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Variant 2: PARALLEL HISTOGRAM, NO SYNCHRONIZATION (deliberately broken!).
 *
 * The image rows are split into strips, one task per strip on a fixed
 * thread pool -- exactly like the parallel blur. But unlike the blur,
 * this kernel is a REDUCTION: the shared bins are indexed by pixel
 * VALUE, not position. Threads working on completely different rows
 * still hit the same bin whenever their pixels have the same brightness,
 * so partitioning by rows does not separate the writes.
 *
 * THE BUG: hist[v]++ is a read-modify-write (load, add 1, store). When
 * two threads interleave on the same bin, one store overwrites the
 * other and a count is silently LOST. The sum of all bins comes out
 * smaller than the pixel count, and differently on every run.
 *
 * The program verifies itself against a sequential reference and prints
 * how many counts were lost.
 *
 * Requires JDK 8+.
 */
public class ParallelHistogramNoSync {

    // !!! SHARED bins, updated by every worker thread with no protection.
    static final long[] hist = new long[256];

    public static void main(String[] args) throws Exception {
        String name = args.length > 0 ? args[0] : "aroma.jpg";
        BufferedImage img = ImageIO.read(new File("images/input/" + name));
        int w = img.getWidth(), h = img.getHeight();
        final int[] pixels = img.getRGB(0, 0, w, h, null, 0, w);

        // Correct reference, computed sequentially, for self-verification.
        long[] reference = new long[256];
        for (int i = 0; i < pixels.length; i++) reference[brightness(pixels[i])]++;

        int threads = Runtime.getRuntime().availableProcessors();
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch done = new CountDownLatch(threads);
        int rowsPerTask = (h + threads - 1) / threads;

        long start = System.nanoTime();
        for (int t = 0; t < threads; t++) {
            final int y0 = t * rowsPerTask;
            final int y1 = Math.min(h, y0 + rowsPerTask);
            pool.submit(() -> {
                try {
                    for (int y = y0; y < y1; y++) {
                        for (int x = 0; x < w; x++) {
                            hist[brightness(pixels[y * w + x])]++;  // RACE: lost updates
                        }
                    }
                } finally {
                    done.countDown();
                }
            });
        }
        done.await();
        long ms = (System.nanoTime() - start) / 1_000_000;
        pool.shutdown();

        long counted = sum(hist);
        System.out.println("=== Parallel histogram, NO synchronization ("
                + threads + " threads) ===");
        System.out.println("Image: " + name + " (" + w + "x" + h + ", "
                + (w * h) + " pixels)");
        System.out.println("Time: " + ms + " ms");
        System.out.println("Sum of all bins: " + counted);
        System.out.println("LOST counts:     " + (sum(reference) - counted)
                + "   (different every run -- that is the race)");
        System.out.println("Bin checksum:    " + checksum(hist)
                + "   (sequential reference: " + checksum(reference) + ")");

        // Chart with the correct counts overlaid in red: wherever the red
        // line floats above a bar top, counts were lost to the race.
        File chart = new File("images/output/histogram_nosync.png");
        SequentialHistogram.drawHistogram(hist, reference,
                "Parallel histogram, NO synchronization (" + threads
                + " threads) -- lost " + (sum(reference) - counted) + " counts",
                chart);
        System.out.println("Wrote " + chart.getPath());
    }

    /** Brightness (luminance) of an RGB pixel, 0..255. */
    static int brightness(int rgb) {
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        return (299 * r + 587 * g + 114 * b) / 1000;
    }

    static long sum(long[] hist) {
        long s = 0;
        for (long v : hist) s += v;
        return s;
    }

    /** Position-weighted checksum: differs if ANY bin has the wrong count. */
    static long checksum(long[] hist) {
        long s = 0;
        for (int i = 0; i < hist.length; i++) s += (i + 1) * hist[i];
        return s;
    }
}
