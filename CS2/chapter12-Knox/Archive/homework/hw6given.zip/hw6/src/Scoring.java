public class Scoring {

    /* 
     * 0 = OOB (out of bounds)
     * 1 = EMPTY
     * 2 = TREES
     * 3 = VILLAGE
     * 4 = FARM
     * 5 = WATER
     * 6 = MONSTER
     * 7 = MOUNTAIN
     * 8 = MOUNTAINW
     */

     public static int numTrees(Grid g) {
        int count = 0;
        for(int i=0; i < g.xdim(); i++)
            for(int j=0; j < g.ydim(); j++)
                if(g.get(i,j) == Terrain.TREES)
                    count++;
        return count;
     }

    public static int seaside(Grid g) {
        //return number of village locations next to at least one water location
    
        return 0;
    }

    public static int villageSize(Grid g, int x, int y) {
        //return number of village locations reachable from (x,y) going only thru village terrain

        return 0;
    }

}
