import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestScoring {

    Grid grid1;

    /* 
     * 0 = OOB (out of bounds)
     * 1 = EMPTY
     * 2 = TREES
     * 3 = VILLAGE
     * 4 = FARM
     * 5 = WATER
     * 6 = MONSTER
     * 7 = MOUNTAIN
     * 8 = MOUNTAINW
     */

    @Before
    public void setup() {
        int[][] gridArray1 = new int[][]{{1, 1, 2, 3},
									     {2, 1, 1, 1},
									     {1, 2, 1, 2}};
        grid1 = new Grid(gridArray1);
    }

    @Test
    public void testNumTrees() {
        assertEquals(4, Scoring.numTrees(grid1));
    }
}
