import java.util.Iterator;

public class Grid {

	private Terrain[][] loc;

	public Grid(int xdim, int ydim) {
		loc = new Terrain[xdim][ydim];
		for (int i = 0; i < xdim; i++)
			for (int j = 0; j < ydim; j++)
				loc[i][j] = Terrain.EMPTY;
	}

	public Grid(int[][] grid) {
		// constructor that takes numeric codes for the Terrain
		// assumes grid is rectangular
		// reverses coordinates so that x is column number if created w/ initializer

		Terrain[] terrains = Terrain.values();

		int ydim = grid.length;
		int xdim = grid[0].length;
		loc = new Terrain[xdim][ydim];
		for (int i = 0; i < xdim; i++)
			for (int j = 0; j < ydim; j++)
				loc[i][j] = terrains[grid[j][i]];
	}

	public int xdim() {
		return loc.length;
	}

	public int ydim() {
		return loc[0].length;
	}

	public Terrain get(int x, int y) {
		if (x < 0 || x >= loc.length)
			return Terrain.OOB;
		if (y < 0 || y >= loc[0].length)
			return Terrain.OOB;
		return loc[x][y];
	}

	public Terrain get(Point p) {
		return get(p.x, p.y);
	}

	public void set(int x, int y, Terrain t) {
		Terrain curr = get(x, y); // current Terrain at that location

		if (curr == Terrain.EMPTY || (curr == Terrain.MOUNTAINW && t == Terrain.MOUNTAIN))
			loc[x][y] = t;
		else
			throw new IndexOutOfBoundsException();
	}

	public void set(Point p, Terrain t) {
		set(p.x, p.y, t);
	}
}
