/*
 * Class to represent an ordered pair of integers (a 2D point)
 *
 * Coordinate values are accessible via public attributes
 */

public class Point {
    public int x;    //coordinates of the point
    public int y;

    public Point(int x, int y) {
	    this.x = x;
	    this.y = y;
    }

    public boolean equals(Object other) {
        if(!(other instanceof Point))
            return false;
        Point otherP = (Point) other;
        return (x == otherP.x) && (y == otherP.y);
    }

    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public int hashCode() {
		return x + 31 * y;
	}
}
