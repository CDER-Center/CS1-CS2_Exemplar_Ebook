import java.awt.*;

public enum Terrain {
	OOB(0, 0, 0, " "),
	EMPTY(-1, 0, 0, " "),
	TREES(0, 153, 76, "T"),
	VILLAGE(204, 0, 0, "V"),
	FARM(204, 204, 0, "F"),
	WATER(100, 100, 255, "W"),
	MONSTER(178, 102, 255, "M"),
	MOUNTAIN(96, 96, 96, " "),
	MOUNTAINW(96, 96, 96, " ");

	private final Color color;
	private final Color translucentColor;
	private final String label;
	static private final Color gold = new Color(255, 215, 0);

	Terrain(int r, int g, int b, String label) {
		if (r == -1) {
			color = null;
			translucentColor = null;
		} else {
			color = new Color(r, g, b);
			translucentColor = new Color(r, g, b, 75);
		}
		this.label = label;
	}
}
