import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestCar {

    private Car c;

    @Before
    public void setup() {
    }

    @Test
    public void testSomething() {

    }
}
