public interface PrintQueue {

	public void submit(String filename, boolean manager);
	//adds a job to the queue
	//the first argument is a string (allegedly the file to print)
	//the second indicates whether the added job belongs to a manager
	
	public boolean hasNextJob();
	//returns whether any jobs are waiting in the queue
	
	public String nextJob();
	//returns the filename of the next job to run
	//(throws NoSuchElementException if there isn't one)
}
