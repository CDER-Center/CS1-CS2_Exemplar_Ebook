import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TestPrintQueue {
    
    PrintQueue p;

    @Before
    public void setup() {
        //p = new WorkingPrintQueue();
        p = new BadPrintQueue();
    }

    @Test
    public void test1() {
    }
}
