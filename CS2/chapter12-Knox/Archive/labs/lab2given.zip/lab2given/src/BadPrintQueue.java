/*
 * Implementation of PrintQueue that doesn't work.
 * (Manager jobs are just added to the front of the queue, but their order is not respected.)
 */

import java.util.*;

public class BadPrintQueue implements PrintQueue {
	private LinkedList<String> jobs;          //waiting jobs
	
	public BadPrintQueue() {
		jobs = new LinkedList<String>();
	}
	
	public void submit(String filename, boolean manager) {
		if(manager)
			jobs.addFirst(filename);
		else
			jobs.add(filename);
	}
	
	public boolean hasNextJob() {
		return (jobs.size() > 0);
	}
	
	public String nextJob() {
		if(jobs.size() > 0)
			return jobs.poll();
		throw new NoSuchElementException();
	}
}
