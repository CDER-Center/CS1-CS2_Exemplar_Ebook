import java.util.*;

public class WorkingPrintQueue implements PrintQueue {
	private LinkedList<String> managerJobs;   //waiting manager jobs
	private LinkedList<String> engineerJobs;  //waiting engineer jobs
	
	public WorkingPrintQueue() {
		managerJobs = new LinkedList<String>();
		engineerJobs = new LinkedList<String>();
	}
	
	public void submit(String filename, boolean manager) {
		if(manager)
			managerJobs.add(filename);
		else
			engineerJobs.add(filename);
	}
	
	public boolean hasNextJob() {
		return (managerJobs.size() > 0)  || (engineerJobs.size() > 0);
	}
	
	public String nextJob() {
		if(managerJobs.size() > 0)
			return managerJobs.poll();
		if(engineerJobs.size() > 0)
			return engineerJobs.poll();
		throw new NoSuchElementException();
	}
}
