interface Node< T> {
	public int size();  //returns size of list (# values) starting with this Node
	//public boolean contains(T val);  //returns whether list starting with this Node contains val
	//public T get(int index);  //return value at given index (0 is list starting at this Node)
	                          //throws IndexOutOfBoundsException if index is invalid 
}

class EmptyNode< T> implements Node< T> {
	
	public int size() {
	}
}

class NonEmptyNode< T> implements Node< T> {
	T value;
	Node< T> next;

	public NonEmptyNode(T value, Node< T> next) {
		this.value = value;
		this.next = next;
	}
	
	public int size() {
	}
}

public class RecursiveList< T> {

	private Node< T> head;

	public RecursiveList() {
		head = new EmptyNode< T>();
	}

	public void addFront(T value) {
		head = new NonEmptyNode< T>(value, head);
	}

	public int size() {
		return head.size();
	}
}
