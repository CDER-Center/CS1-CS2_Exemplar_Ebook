import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RecursiveListTest {
	RecursiveList< String> list;
	
	@Before
	public void setUp() throws Exception {
		list = new RecursiveList< String>();
	}
	
	@Test
	public void testSize() {
		assertEquals(0, list.size());
		list.addFront("hello");
		assertEquals(1, list.size());
		list.addFront("there");
		assertEquals(2, list.size());
	}
	
	/*
	@Test
	public void testContains() {
		list.addFront("Hi");
		list.addFront("Hello");
		list.addFront("Bye");
		assertEquals(true, list.contains("Hi"));
		assertEquals(true, list.contains("Hello"));
		assertEquals(true, list.contains("Bye"));
		assertEquals(false, list.contains("Not there"));
	}
    */
	
	/*
	@Test
	public void testGet() {
		try {
			list.get(0);
			fail();
		} catch(IndexOutOfBoundsException ex) {
			//NOTHING; correct exception thrown
		}
		
		list.addFront("Hi");
		list.addFront("Hello");
		list.addFront("Bye");
		assertEquals("Bye", list.get(0));
		assertEquals("Hello", list.get(1));
		assertEquals("Hi", list.get(2));
		
		try {
			list.get(-1);
			fail();
		} catch(IndexOutOfBoundsException ex) {
			//NOTHING; correct exception thrown
		}
		
		try {
			list.get(3);
			fail();
		} catch(IndexOutOfBoundsException ex) {
			//NOTHING; correct exception thrown
		}
	}
	*/
	
	/*
	@Test
	public void testIndexOf() {
			for(int i=0; i<200; i++)
				list.addFront("hello");
			assertEquals(-1, list.indexOf("bye"));
	}
	*/
	
	/*
	@Test
	public void testAdd() {
		list.add("Hi");
		list.add("Hello");
		list.add("CS 142");
		list.add("David");
		assertEquals(4, list.size());
		assertEquals("Hi", list.get(0));
		assertEquals("Hello", list.get(1));
		assertEquals("CS 142", list.get(2));
		assertEquals("David", list.get(3));
	}
	*/
}
